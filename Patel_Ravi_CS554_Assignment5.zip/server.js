const express = require("express")
const bodyParser = require("body-parser")

const redis = require("redis")
const client = redis.createClient()
const cache = require("express-redis-cache")()

const app = express()

const peopleData = require("./data/people")

const bluebird = require("bluebird")
bluebird.promisifyAll(redis.RedisClient.prototype)
bluebird.promisifyAll(redis.Multi.prototype)

const {promisify} = require("util")
const getAsync = promisify(client.get).bind(client)


/* -------------------------------------------------------------------------------- */

client.on("connect", ()=>{
    console.log("Connected")
})

/* -------------------------------------------------------------------------------- */

app.use(bodyParser.json())


/* --------------------------------- Routes --------------------------------------- */
// Default Route
app.get('/', (req,res) => {
    res.json({page:`loading route '/' `})


})

// /api/people/history/
app.get('/api/people/history', (req,res) => {

    /**  Will return array of last 20 users in cache from recently viewed list **/
    /**  Will return user information **/
    
    const history = 'history'
    return client.get(history, (err, people) =>{
        if(people) {
            return res.json({data: JSON.stringify(client.lrange(history,0,20))})
        }
        else{
            return res.json({error: "Error: "+err})
        }
    })
})

app.get('/api/people/:id', (req,res) => {
    
    const history = 'history'
    let personID = parseInt(req.params.id)
    client.lpush(history, [JSON.stringify(peopleData.getById(personID))])
    return res.json({data: JSON.stringify(peopleData.getById(personID))})
})


app.listen(3000, () => {
    console.log("Running routes in localhost")
})